// Transaction id should be replaced in the file to connect ot the backend
const Contract = {
  id: '0x95b2f7f949f7b98d9306db39fd7ac120d51c1bca'
}

module.exports = Contract
